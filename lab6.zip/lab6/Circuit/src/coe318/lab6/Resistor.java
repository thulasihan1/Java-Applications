
package coe318.lab6;

/**
 *
 * @author Tesla69
 */
public class Resistor {
    int resId;
    double resistance;
    Node node1, node2;
    static int counter =1;

    /**
     *
     *
     * @param resistance
     * @param node1
     * @param node
     */
    
    public Resistor( double resistance, Node node1, Node node2)
     {
         if(resistance<=0){
         throw new IllegalArgumentException();
         
     }   
     if(node1==null||node2==null){
         throw new IllegalArgumentException();
     }
        this.resistance=resistance;
        this.node1= node1;
        this.node2= node2;
        this.resId= counter;
        counter++;
     }
        
        
        
    
  public Node[] getNode(){
      return new Node[]{node1, node2};
  }  
    
    @Override
    public String toString(){
    
    return "R" + ""+ this.resId+" "+node1+" "+node2+" "+resistance;
    
}  

    private static class node {

        public node() {
        }
    }

    private static class resistance {

        public resistance() {
        }
    }
  
  
  
  
}
