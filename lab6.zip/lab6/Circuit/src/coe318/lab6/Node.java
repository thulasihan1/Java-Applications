
package coe318.lab6;
import java.util.*;

public class Node {
    private int id;
    private static int counter= 0;
    public Node(){
        this.id= counter;
        counter++;
        
    }
    public String toString(){
        return ""+this.id;
    }
    
    
}
