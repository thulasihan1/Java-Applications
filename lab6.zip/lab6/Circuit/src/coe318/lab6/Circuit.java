/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab6;
import java.util.*;
/**
 *
 * @author Tesla69
 */
public class Circuit {
    ArrayList<Resistor> resistors;
    private static Circuit instance= null;
    public static Circuit getInstance(){
        if(instance==null){
            return instance = new Circuit();
            
        }else{
            return instance;
        }
    }
     void add (Resistor r){
         resistors.add(r);
         
     }
    private Circuit(){
        resistors = new ArrayList<Resistor>();
    }
    public String toString(){
        String res ="";
        for(int i=0; i<resistors.size(); i++){
            res+= resistors.get(i) +"\n";
        }
        return res;
    }
    
    
    
}
