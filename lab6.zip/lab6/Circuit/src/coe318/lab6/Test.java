/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab6;

/**
 *
 * @author Tesla69
 */
public class Test {
    public static void main(String [] args){
        Node n1= new Node();
        Node n2= new Node ();
        Node n3= new Node();
        Resistor r1= new Resistor(10.1, n1, n2);
        Resistor r2= new Resistor(5.2, n2, n3);
        Circuit c= Circuit.getInstance();
        c.add(r1);
        c.add(r2);
        System.out.println(c);
    }
    
}
