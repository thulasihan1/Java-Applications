package coe318.lab5;

import java.util.Scanner;

public class SimpleUI implements UserInterface {
    private BlackjackGame game;
    private Scanner user = new Scanner(System.in);

  @Override
    public void setGame(BlackjackGame game) {
        this.game = game;
    }

  @Override
    public void display() {
        System.out.println("H cards:");
        for(Card c:game.getHouseCards().getCards()){
            System.out.println(c.toString());
        }
        System.out.println("your cards:");
        for(Card b:game.getYourCards().getCards()){
            System.out.println(b.toString());
        }
    }

  @Override
    public boolean hitMe() {
        boolean yes = false;
        char i;
        System.out.println("Do you want another card?");
        i= user.next(".").charAt(0);
        if(i=='y'){
            yes=true;
        }
        else {
            yes= false;
        }
        return yes;
    }

  @Override
    public void gameOver() {
        int hoscore ;
        int yoscore ;
        hoscore = game.score(game.getHouseCards());
        yoscore = game.score(game.getYourCards());
        
        System.out.println("\n Finalresult: House Cards: \n");
        System.out.println(game.getHouseCards().toString());
        
        System.out.println("\nYour Final Cards: \n");
        System.out.println(game.getYourCards().toString());
        
        System.out.println("\nFinal House Score: " + hoscore);
        System.out.println("Your Final Score: " + yoscore);
        
        String a = "\nYou Win";
        String b = "\nHouse Wins";
        if (yoscore < 21 && yoscore>hoscore)
            System.out.println(a);
        else if (yoscore <21 && hoscore>21)
            System.out.println(a);
        else 
            System.out.println(b);

    }

}