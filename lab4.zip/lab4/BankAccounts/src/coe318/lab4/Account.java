/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package coe318.lab4;

/**
 *
 * @author t3sivara
 */
public class Account {
    
  String name;
  double balance;
  int number;
  double amount;
  public Account(String name,int number, double initialBalance)
  {
      
      this.name=name;
      this.number= number;
      balance= initialBalance;
          
      
  }
  
  public String getName()
  {
      return name;
  }
  public int getNumber()
  {
      return number;
  }
  public double getBalance()
  {
      return balance;
  }
  
  public boolean withdraw (int num)
  {
      if(num<balance && num>0)
      {
          balance= balance-num;
          return true;
      }
      else 
          return false;
      
      
  }
  public boolean deposit (int num)
  {
      if(num>0)
      {
          balance= balance+num;
          return true;
      }
      else 
          return false;
      
      
  }
  
  @Override
public String toString() {//DO NOT MODIFY
return "(" + getName() + ", " + getNumber() + ", " +
String.format("$%.2f", getBalance()) + ")";
}

    
    
    
    
}
